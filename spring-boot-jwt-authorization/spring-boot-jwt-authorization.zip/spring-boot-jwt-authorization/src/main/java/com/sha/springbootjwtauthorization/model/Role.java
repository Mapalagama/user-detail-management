package com.sha.springbootjwtauthorization.model;

import javax.persistence.Enumerated;

public enum Role {
    USER,
    ADMIN

}
